### Challenege_Challenge.xlsm

### Overview of Project
## The Purpose and background are well defined
# VBA is a language used for programming tasks and developing additional function in Excel worksheets. VBA is great for automating actions for saving time and high speeds 

### Results
## The analysis is well described with screenshots and code
# I screenshots those and put in file to sumbit

### Summary 

## There is a detailed statement on the advantages and disadvantages of refactoring code in general
# Advantages: Saving time and cool to use code more fun than bored regular excel
# Disadvantage, for who beginner maybe struggle because they do not know what doing with codes. 
## There is a detailed statement on the advantages and disadvantages of the original and refactored VBA script
# Advantages, Speed up types and clear with codes
# Disadvantage, those get an errors sometime but I want to know why, and they could clear inustruction to solve error. I have to check up on google. 
